# 05 · Advanced MCP Configuration

## What it is
Configuring MCP servers properly: URLs, headers and secrets. It also covers combining several servers, limiting their tools, handling failures, and building your own server.

## Why use it
- Share one team setup through `.mcp.json` in Git.
- Keep secrets out of Git.
- Expose your own data or code to Claude as tools.

## How it works

**`.mcp.json` (project scope, committed)**
```json
{
  "mcpServers": {
    "github": {
      "type": "http",
      "url": "https://api.githubcopilot.com/mcp/",
      "headers": { "Authorization": "Bearer ${GITHUB_PAT}" }
    },
    "csv-tools": {
      "type": "stdio",
      "command": "python3",
      "args": ["mcp_server.py"],
      "env": { "DATA_DIR": "./data" }
    }
  }
}
```
- **Remote (`http`):** every tool call is an HTTP request with your headers attached.
- **Local (`stdio`):** Claude starts a process and talks over stdin/stdout. No network, so secrets go in `env`.
- Use `${ENV_VAR}` for secrets so the real token is never committed.

**Add from the CLI**
```bash
claude mcp add --transport http github https://api.githubcopilot.com/mcp/ --scope project --header "Authorization: Bearer ${GITHUB_PAT}"
claude mcp add --transport stdio csv-tools --scope project -- python3 mcp_server.py
```

**Combining servers:** Claude merges all tool lists into one registry. The tool *description* decides which tool gets picked. Write clear, distinct descriptions.

**Tool filtering (3 levels):** server exposes fewer tools → client config allow/block list → instructions telling Claude to ignore some tools.

**Four failure modes**

| Failure | Meaning |
|---|---|
| Connection | Server unreachable. Tools are missing |
| Tool error | Reachable, but the call failed (JSON-RPC error) |
| Timeout | No response in time |
| Partial success | Looks like success but part failed. Check the result content |

**Debugging layers:** transport (does it connect? `/mcp`) → protocol (JSON-RPC messages, MCP Inspector) → tool-use trace (expandable tool calls in the UI).

**Building a stdio server in Python** (`pip install "mcp[cli]"`, `mcp_server.py`):
```python
from mcp.server.fastmcp import FastMCP
from csv_reader import load_rows, filter_rows, summarize

mcp = FastMCP("csv-tools")

@mcp.tool()
def summarize_csv(path: str, category: str = "") -> dict:
    """Return row count, revenue and top product for a sales CSV, optionally for one category."""
    rows = load_rows(path)
    if category:
        rows = filter_rows(rows, category)
    return summarize(rows)

@mcp.resource("csv://sample")
def sample() -> str:
    """The raw sample sales file."""
    return open("data/sales.csv").read()

if __name__ == "__main__":
    mcp.run()          # stdio by default
```
Test it with `npx @modelcontextprotocol/inspector python3 mcp_server.py`.

## Try it on the CSV project
1. Save the server above next to `csv_reader.py` and register it as `csv-tools`.
2. In Claude: `/mcp` shows `csv-tools: connected, 1 tool`.
3. Ask: *"What is the revenue for Electronics in data/sales.csv?"* and watch it call `summarize_csv`.
4. For an HTTP server, switch `mcp.run(transport="streamable-http")` and add an API-key header check.

## Gotchas
- Never commit a literal token. Use `${VAR}`.
- stdio servers must not print debug text to stdout. Use stderr.
- Give each tool a precise description and typed params, or Claude will misuse it.
- Read-only servers are safer. Add write tools deliberately.
