# Claude Code Cheat Sheet

One-page notes for each module of the Claude AI Automation Engineering course. Each sheet answers **what it is, why use it, how it works**, then shows it on one tiny shared project. Installation and setup are left out.

## The shared project (30 seconds)
[`sample-project/`](sample-project/) is a ~40-line Python script that reads `data/sales.csv`, optionally filters by category and prints row count, revenue and top product. There is no API, no framework and nothing to install. Read it once and then ignore it. Every module adds a Claude feature on top of it.

```bash
cd sample-project
python3 csv_reader.py data/sales.csv --category Furniture
python3 -m unittest discover tests
```

## Modules

| # | Sheet | One-line summary |
|---|---|---|
| 01 | [Intro & CLAUDE.md](01-intro-and-claudemd.md) | What Claude Code is, commands, context, memory files |
| 02 | [Core workflows](02-core-workflows.md) | Prompting, code gen, debugging, tests, docs |
| 03 | [Skills](03-skills.md) | Reusable instruction folders (`SKILL.md`) |
| 04 | [MCP essentials](04-mcp-essentials.md) | Connect Claude to outside tools and data |
| 05 | [Advanced MCP](05-advanced-mcp.md) | `.mcp.json`, auth, failures, build your own server |
| 06 | [Built-in subagents](06-builtin-subagents.md) | Explore / Plan / General-purpose, isolated context |
| 07 | [Custom subagents](07-custom-subagents.md) | Narrow prompts, tools, scope, testing |
| 08 | [Agent teams](08-agent-teams.md) | Multiple Claude sessions that talk to each other |
| 09 | [Hooks](09-hooks.md) | Scripts that run automatically before and after actions |
| 10 | [Plugins](10-plugins.md) | Bundle and share all of the above |
| — | [Capstone](capstone/README.md) | Support-ticket platform that combines everything |

## Sheet format
1. **What it is** 2. **Why use it** 3. **How it works** 4. **Try it on the CSV project** 5. **Gotchas**

## How the modules fit together
`CLAUDE.md` (facts) → **skills** (procedures) → **MCP** (outside tools) → **subagents** (delegated work) → **teams** (collaborating agents) → **hooks** (automatic guardrails) → **plugins** (package it all).
