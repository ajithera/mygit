# Sample Project: CSV Reader

A ~40-line Python script. It reads `data/sales.csv`, optionally filters by category, and prints row count, revenue and top product. Python standard library only, no API, no installs.

```bash
python3 csv_reader.py data/sales.csv                       # all rows
python3 csv_reader.py data/sales.csv --category Furniture  # one category
python3 -m unittest discover tests                         # run tests
```

| File | Purpose |
|---|---|
| `csv_reader.py` | `load_rows`, `filter_rows`, `summarize`, plus a tiny CLI |
| `data/sales.csv` | 15 rows: id, product, category, price, qty |
| `tests/test_csv_reader.py` | 4 unit tests |

This is the starting state. Every cheat sheet module adds one Claude feature on top of it.
