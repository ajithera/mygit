import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from csv_reader import filter_rows, load_rows, summarize

DATA = os.path.join(os.path.dirname(__file__), "..", "data", "sales.csv")


class CsvReaderTests(unittest.TestCase):
    def test_load_rows_converts_numbers(self):
        rows = load_rows(DATA)
        self.assertEqual(len(rows), 15)
        self.assertIsInstance(rows[0]["price"], float)
        self.assertIsInstance(rows[0]["qty"], int)

    def test_filter_rows_ignores_case(self):
        rows = filter_rows(load_rows(DATA), "electronics")
        self.assertEqual(len(rows), 6)

    def test_summarize_empty(self):
        self.assertEqual(summarize([])["count"], 0)

    def test_summarize_top_product(self):
        stats = summarize(filter_rows(load_rows(DATA), "Furniture"))
        self.assertEqual(stats["top_product"], "Office Chair")


if __name__ == "__main__":
    unittest.main()
