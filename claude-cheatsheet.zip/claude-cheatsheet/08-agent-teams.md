# 08 · Agent Teams

## What it is
An agent team is several full Claude sessions working together. One session is the **lead**, and the **teammates** run in their own context windows, share a task list and can message each other directly. The feature is experimental and needs Claude Code 2.1.32 or later.

## Why use it
- **Parallel speed-up:** independent work happens at the same time.
- **Specialist focus:** each teammate has one lens (security, tests, docs).
- **Peer review:** teammates can challenge each other's findings.

## How it works

**Subagents vs teams**

| | Subagents | Agent teams |
|---|---|---|
| Communication | Only report back to the main agent | Message each other |
| Coordination | Main agent controls everything | Shared task list, self-claiming |
| Cost | Lower | Higher: each teammate is a full Claude |
| Best for | Focused tasks where only the result matters | Complex work needing discussion or review loops |

**Roles:** *Lead* (plans, assigns, synthesises, cleans up) · *Specialists* (builders or researchers) · *Reviewers* (read-only quality gate).

**Three patterns**

| Pattern | Flow | Use when |
|---|---|---|
| Sequential pipeline | Researcher → Builder → Tester → Reviewer | Each step needs the previous output |
| Parallel fan-out | Several reviewers at once → lead merges | Independent checks on the same artifact |
| Feedback loop | Writer ⇄ Validator until approved (cap the rounds) | Quality bar must be met |

**Shared context:** each teammate has a private context window. Share through files (a brief such as `.claude/brief.md`, a progress file) and direct messages. All teammates load `CLAUDE.md`. Teammates can use your custom agent definitions (their `tools` and `model` apply).

**Controls:** `Shift+Down` cycles through teammates · `Ctrl+T` toggles the task list · ask the lead "Shut down all teammates" then "Clean up the team".

**Failure handling:** retry transient errors (5xx, timeouts) with backoff (about 3–5 tries). Don't retry 400/401/403. Add a fallback (cheaper model or partial result), then escalate to a human. Set a max review-round count. Agents have no built-in turn or cost limit.

**Cost vs latency:** parallel is faster in wall-clock time but costs about N times the tokens. Use it only when the speed is worth it.

**Enable (per developer):** in `~/.claude/settings.json`
```json
{ "env": { "CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS": "1" } }
```

## Try it on the CSV project
**Parallel fan-out review:**
```
Create an agent team to review csv_reader.py before release. Spawn three teammates at once:
- bug-reviewer (csv-reviewer agent type): hunt for bugs and missing edge cases.
- test-reviewer (test-runner agent type): run the tests, report untested functions.
- doc-reviewer: check README.md matches the real CLI options.
Each sends a short report to me. Then give a PASS/FAIL verdict with a prioritised fix list.
```
**Pipeline:** researcher reads the code → builder adds `--top N` → tester writes tests → reviewer audits. Use task dependencies so each waits for the previous.

## Gotchas
- Never let two teammates edit the same file.
- Don't use teams for sequential, tightly dependent or tiny tasks. A single session is cheaper.
- Only one team at a time. Clean up before starting another.
- `/resume` doesn't restore teammates.
