# 06 · Subagents: Built-in and Custom (Basics)

## What it is
A subagent is a separate Claude instance with its own context window, system prompt and tools. Your main session hands it a job, and only its final summary comes back.

## Why use it
- **Keeps your context clean:** a subagent can read a dozen files and only a short answer lands in your chat.
- **Cheaper and faster:** a subagent can run on a smaller model such as Haiku.
- **Safer:** you can restrict it to read-only tools.

## How it works

**Inline vs delegated**

| | Normal prompt | Subagent |
|---|---|---|
| Where work happens | In your main context | In a separate context |
| What returns | Everything accumulates | Only the final summary |
| System prompt / model | Session default | Can be specialised per agent |
| Can it spawn subagents? | Yes | No |

**Built-in subagents**

| Agent | Model | Tools | Used when |
|---|---|---|---|
| **Explore** | Haiku (fast, cheap) | Read-only | Searching or understanding code. Thoroughness: quick / medium / very thorough |
| **Plan** | Inherits | Read-only | Plan mode is on and Claude needs to research first |
| **General-purpose** | Inherits | All tools | Multi-step work that needs both exploring and editing |

There is no separate "browser" or "code execution" subagent. `WebSearch`/`WebFetch` and `Bash` give any agent those abilities.

**Custom subagent scope**

| Path | Scope | In Git? |
|---|---|---|
| `.claude/agents/<name>.md` | This project | Yes |
| `~/.claude/agents/<name>.md` | All your projects | No |

A file is picked up as soon as it is saved.

**A custom agent file**
```markdown
---
name: readme-checker
description: Use this agent to check whether README.md matches the code. Activates when asked to verify or audit the README.
tools:
  - Read
  - Grep
  - Glob
---
You compare README.md with csv_reader.py. List every option or function mentioned in one but not the other.
Reply "README is accurate" if there are none.
```

**Frontmatter fields**

| Field | Notes |
|---|---|
| `name`, `description` | Required. Claude reads the description to decide when to delegate |
| `tools` / `disallowedTools` | Allowlist / blocklist. Enforced by Claude Code, not just advisory |
| `model` | `sonnet`, `opus`, `haiku` or inherit |
| `maxTurns`, `permissionMode`, `memory`, `skills`, `effort`, `background` | Optional controls |

**Two ways to invoke**
- **Automatic:** you ask in plain language ("Does the README match the code?") and Claude matches the description.
- **Explicit:** "Use the readme-checker agent…". Use it when you want certainty.

**Permissions:** a subagent can never exceed its parent's permissions, and permission prompts still appear.

## Try it on the CSV project
```
> Use the Explore subagent: find every place price or qty is used, with file and line.
> /plan  Add a --top N option that lists the N best-selling products.   (Plan subagent researches)
> Use a general-purpose subagent to implement the plan and run the tests.
```
Then create `.claude/agents/readme-checker.md` (above) and ask "Does the README match the code?"

## Gotchas
- Don't delegate trivial single-file questions. Inline is cheaper.
- A vague `description` means Claude never picks the agent.
- Tool restrictions only work if you actually set `tools:`.
