# 03 · Claude Skills

## What it is
A skill is a folder with a `SKILL.md` file: a reusable instruction sheet for one type of task. Claude reads it when a task matches, or you run it by name as `/skill-name`.

## Why use it
- **Consistency:** the same steps every session, because Claude has no memory between sessions.
- **Environment knowledge:** which tool, path or format your project uses, so there's no guessing.
- **Team standards:** one person writes the procedure and everyone gets it.

**Skill vs `CLAUDE.md`:** `CLAUDE.md` holds facts needed every session and is always loaded. A skill holds a procedure and is loaded only when needed.

## How it works

**Where skills live**

| Scope | Path | Shared via Git? |
|---|---|---|
| Project | `.claude/skills/<name>/SKILL.md` | Yes |
| User | `~/.claude/skills/<name>/SKILL.md` | No, all your projects |

If both exist for the same task, the project skill wins.

**Anatomy of `SKILL.md`**
```markdown
---
name: csv-summary
description: Summarize a sales CSV file. Use when the user asks for totals, revenue,
  top products or a summary of a .csv file. Do NOT use for editing CSV files.
disable-model-invocation: false      # true = only runs when YOU type /csv-summary
allowed-tools: Bash(python3 *) Read  # tools it may use without asking
---
# CSV Summary
1. Run `python3 csv_reader.py $ARGUMENTS`.
2. Show the result as a table: Rows | Revenue | Top product.
3. If the file is missing, say so. Never invent numbers.
```

**Selection flow:** your request → Claude compares it with every skill's `name` + `description` → reads the matching `SKILL.md` → follows it.

The `description` is the router and the body is the instructions. A good description has:
1. One clear trigger sentence
2. Keywords users would say
3. Intent patterns
4. File and task types
5. Explicit exclusions ("Do NOT use for…")

**Related memory pieces**

| Item | Purpose |
|---|---|
| `.claude/rules/*.md` with `paths:` | Rules loaded only when Claude touches matching files |
| `CLAUDE.local.md` | Personal, not committed |
| `/memory`, `/skills` | Inspect what's loaded |

Path-scoped rule example (`.claude/rules/tests.md`):
```markdown
---
paths:
- "tests/**/*.py"
---
Use unittest only. Reset state in setUp. Assert on values, not just "no error".
```

**Versioning:** add `version`, `last_updated` and a `changelog` to the frontmatter. A stale skill gives wrong answers silently.

## Try it on the CSV project
1. Create `.claude/skills/csv-summary/SKILL.md` with the example above.
2. In Claude: `/csv-summary data/sales.csv --category Furniture`.
3. Add a side-effect skill, `/commit-and-push`, with `disable-model-invocation: true` so Claude never runs it on its own.

## Gotchas
- A vague description means it never triggers, or triggers wrongly. Add exclusions.
- Skills with side effects (commit, deploy) should set `disable-model-invocation: true`.
- Keep `SKILL.md` short and specific. Long procedures go in supporting files next to it.
