# 10 · Plugins

## What it is
A plugin is a folder with a manifest that **bundles** skills, subagents, hooks and MCP servers into one installable package. It is the distribution unit: build the pieces from modules 03–09, then ship them together.

## Why use it
- **Share once, install anywhere:** a one-line install replaces copying `.claude/` folders between repos.
- **No name clashes:** skills are namespaced, e.g. `/csv-toolkit:csv-summary`.
- **Versioned:** users get updates when you bump the version.

## How it works

**Plugin vs MCP vs skill**

| | Plugin | MCP server | Skill |
|---|---|---|---|
| What | Package of components | Process / URL exposing tools | A `SKILL.md` instruction file |
| Purpose | Sharing and distribution | Connect to external systems | Teach Claude a task |
| Lives in | Folder with `.claude-plugin/plugin.json` | Running process or remote URL | `skills/<name>/SKILL.md` |

**Standalone vs plugin:** standalone `.claude/` gives short names (`/csv-summary`) and is good for one project. A plugin gives namespaced names and is good for sharing. Start standalone, then convert (copy the files and add `plugin.json`).

**Layout**
```
csv-toolkit/
├── .claude-plugin/
│   └── plugin.json          # only this file goes in this folder
├── skills/csv-summary/SKILL.md
├── agents/csv-reviewer.md
├── hooks/hooks.json         # use ${CLAUDE_PLUGIN_ROOT} for script paths
├── .mcp.json                # optional MCP servers
└── README.md
```

**`plugin.json`** (only `name` is required)
```json
{
  "name": "csv-toolkit",
  "displayName": "CSV Toolkit",
  "version": "1.0.0",
  "description": "Summarize and review CSV sales files.",
  "author": { "name": "Your Team", "email": "team@example.com" },
  "license": "MIT",
  "keywords": ["csv", "sales"]
}
```
`name` becomes the namespace. Setting `version` pins users to it until you bump it. Optional fields: `homepage`, `repository`, `skills`, `agents`, `hooks`, `mcpServers`, `userConfig` (values the user is prompted for; `sensitive: true` stores them securely).

**Develop and test locally**
```bash
claude plugin validate .            # add --strict in CI
claude --plugin-dir ./csv-toolkit   # load for one session
> /plugins                          # list
> /mcp                              # bundled MCP server connected?
> /reload-plugins                   # pick up edits without restarting
```

**Scopes** (`claude plugin install name@marketplace --scope …`)

| Scope | Stored in | Who |
|---|---|---|
| user (default) | `~/.claude/settings.json` | You, all projects |
| project | `.claude/settings.json` | Whole team via Git |
| local | `.claude/settings.local.json` | You, this project, gitignored |

**Publish to your team**
1. *Single repo:* commit the plugin into the project.
2. *Private marketplace (for orgs):* a Git repo containing `.claude-plugin/marketplace.json`:
```json
{
  "name": "team-marketplace",
  "owner": { "name": "Your Team" },
  "plugins": [
    { "name": "csv-toolkit",
      "description": "Summarize and review CSV sales files.",
      "source": { "source": "github", "repo": "your-org/csv-toolkit" } }
  ]
}
```
```bash
claude plugin marketplace add your-org/team-marketplace
claude plugin install csv-toolkit@team-marketplace --scope project
claude plugin list | disable | enable | uninstall csv-toolkit
```

## Try it on the CSV project
1. Create `csv-toolkit/` with `.claude-plugin/plugin.json` (above).
2. Copy in the `csv-summary` skill (module 03), the `csv-reviewer` agent (module 07) and a `hooks/hooks.json` that points to `${CLAUDE_PLUGIN_ROOT}/hooks/run_tests.py` (module 09).
3. `claude plugin validate .`, then `claude --plugin-dir ./csv-toolkit`.
4. Ask: *"Summarize the Electronics rows in data/sales.csv"* and *"/csv-toolkit:csv-summary data/sales.csv"*.

## Gotchas
- Only `plugin.json` goes in `.claude-plugin/`. Put skills, hooks and agents at the plugin root.
- Inside a plugin use `${CLAUDE_PLUGIN_ROOT}`, not `${CLAUDE_PROJECT_DIR}`.
- Without `version`, every Git commit counts as a new version.
- Don't hard-code secrets in the manifest. Use `userConfig`.
