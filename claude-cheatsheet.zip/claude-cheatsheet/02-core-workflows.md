# 02 · Core Development Workflows

## What it is
The everyday jobs you give Claude: write code, refactor, debug, test and document. The skill is writing a prompt that gives Claude enough to get it right.

## Why use it
- A precise prompt saves rounds of rework.
- Full error context gets a fix on the first try.
- Tests and docs are the tasks Claude does most reliably.

## How it works

**The 4-part prompt:** `Action + What + Where + Constraints`

| Weak | Strong |
|---|---|
| "Fix the filter" | "In `csv_reader.py`, make `filter_rows` also match on `product`. Keep the signature. Add a test." |

**Good prompt habits**
- Name files (`@csv_reader.py`) and functions.
- Scope it: one function or file at a time.
- State what must not change ("keep the existing CLI flags").
- Say the output you want (table, JSON, plain English).
- Iterate: prompt, review, refine. Don't repeat the same prompt. Say what was wrong.

**Debugging template**
```
ERROR: <paste the full traceback>
WHERE: file / function
WHEN: input that triggers it
EXPECTED: ...   ACTUAL: ...
```

**Workflow checklist**

| Job | Prompt shape |
|---|---|
| New feature | "Add X to Y. Follow the style of Z. Add tests." |
| Refactor | "Refactor X to do A. Keep behavior identical. Tests must still pass." |
| Debug | Paste the full error plus the steps to reproduce |
| Tests | "Write tests for X: happy path, edge cases, error cases" |
| Docs | "Write a README / docstrings explaining why, not what" |
| Audit | "Review X for security and performance issues. List by severity." |
| Multi-file | "List every file you'll touch first. Work models → logic → tests." |

Use a feature branch for anything that touches several files.

## Try it on the CSV project
```
> Add a --min-price option to csv_reader.py that keeps rows with price >= the value.
  Add it to argparse in main(), put the logic in a new filter function,
  and add two unit tests. Don't change existing function signatures.

> Running `python3 csv_reader.py data/bad.csv` gives:
  ValueError: could not convert string to float: 'N/A'
  The file has a bad price on row 3. Make load_rows skip bad rows and report how many were skipped.

> Add docstrings to every function in csv_reader.py, then generate README usage examples.
```

## Gotchas
- "Make it better" gives random results. Say the specific goal.
- Don't paraphrase errors. Paste them whole.
- Ask "is the test wrong or the code wrong?" before letting Claude fix a failing test.
- Review security-sensitive code yourself (auth, input parsing, file handling).
