# Capstone: AI-Powered Customer Support Automation Platform

Separate from the module cheat sheets. It combines modules 02–10 into one system. Source: `02-Capstone-Project-Problem-Statement.pdf`.

## The goal in one line
A support ticket arrives, PII is removed, the ticket is triaged and answered by AI, low-confidence ones go to a human, and every AI answer is logged.

## Pipeline
```
POST /tickets
   │
   ▼  PII pre-hook (redact before any AI call)
   ▼  Triage skill        → urgency + category (JSON)
   ▼  Researcher subagent → draft_response + confidence_score
   │        │ confidence low / failed
   │        ▼  Escalation subagent → status=escalated + escalation_reason
   ▼  Response post-hook  → structured log entry
   ▼  status = closed / escalated
```

## Which module builds which part

| Capstone piece | Module | Folder in the ZIP | What it must do |
|---|---|---|---|
| REST API + tests | 02 | `/api/` | `POST/GET /tickets`, `GET/PATCH/DELETE /tickets/:id`, consistent errors |
| README + API docs | 02 | `/`, `/docs/` | Setup, env vars, OpenAPI or Postman |
| Ticket triage skill | 03 | `/skills/triage/` | Output machine-readable `urgency` (critical/high/medium/low) and `category` |
| MCP server (HTTP) | 04, 05 | `/mcp-server/` | One tool per REST operation, HTTP transport, Claude Code config |
| Researcher subagent | 06, 07 | `/subagents/researcher/` | Read mock product docs, draft answer, return confidence 0.0–1.0 |
| Escalation subagent | 06, 07 | `/subagents/escalation/` | Package full context and reason, route to a human queue |
| Agent-team pipeline | 08 | (wires the above together) | Triage → Researcher → Escalation as a pipeline or feedback loop |
| PII pre-hook | 09 | `/hooks/pre-pii/` | Redact names, emails, phones, addresses, account and payment numbers (`UserPromptSubmit`) |
| Response post-hook | 09 | `/hooks/post-logger/` | JSON log: timestamp, `ticket_id`, response ref, confidence (`PostToolUse` / `Stop`) |
| Tickets plugin | 10 | `/plugins/tickets/` | Natural language to create, read and close tickets, bundling the above |

## Ticket fields (minimum)
`ticket_id`, `subject`, `description`, `submitter_ref`, `status` (open / in_progress / escalated / closed), `urgency`*, `category`*, `draft_response`*, `confidence_score`*, `created_at`, `updated_at`, `resolved_at`, `escalation_reason`. (* = set automatically)

## Suggested build order
1. API + unit tests (2–3 prompts, with the module 02 workflow).
2. PII hook, tested standalone with `echo '{"prompt":"..."}' | python3 hook.py`.
3. Triage skill, then Researcher and Escalation subagents, each tested with a prompt matrix (module 07).
4. HTTP MCP server wrapping the API.
5. Post-logger hook, then plugin packaging, then an end-to-end test of the full lifecycle (create → triage → resolve or escalate → close).

## Rules to remember
- No raw PII may reach a model, on any path.
- Logs must be structured (JSON) and durable.
- Everything must run locally with no paid third-party services.
- Any language is allowed. Python keeps it consistent with the cheat sheets.
