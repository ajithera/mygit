"""Tiny CSV reader: load a sales file, filter by category, print a summary."""
import argparse
import csv


def load_rows(path):
    """Read a CSV file into a list of dicts with price and qty as numbers."""
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    for row in rows:
        row["price"] = float(row["price"])
        row["qty"] = int(row["qty"])
    return rows


def filter_rows(rows, category):
    """Keep only rows whose category matches (case-insensitive)."""
    return [r for r in rows if r["category"].lower() == category.lower()]


def summarize(rows):
    """Return row count, total revenue and the best-selling product."""
    if not rows:
        return {"count": 0, "revenue": 0.0, "top_product": None}
    revenue = sum(r["price"] * r["qty"] for r in rows)
    top = max(rows, key=lambda r: r["price"] * r["qty"])
    return {"count": len(rows), "revenue": round(revenue, 2), "top_product": top["product"]}


def main():
    parser = argparse.ArgumentParser(description="Summarize a sales CSV file.")
    parser.add_argument("path", help="CSV file, e.g. data/sales.csv")
    parser.add_argument("--category", help="only include this category")
    args = parser.parse_args()

    rows = load_rows(args.path)
    if args.category:
        rows = filter_rows(rows, args.category)
    stats = summarize(rows)
    print(f"Rows: {stats['count']}")
    print(f"Revenue: {stats['revenue']}")
    print(f"Top product: {stats['top_product']}")


if __name__ == "__main__":
    main()
