# 04 · MCP Essentials

## What it is
MCP (Model Context Protocol) is an open standard that lets Claude connect to outside tools and data, such as Gmail, GitHub, databases and files. Think of it as USB for AI: one plug shape, any tool.

## Why use it
- Claude gets live data and can take real actions, beyond its training knowledge.
- **Standard:** build or install one server and any MCP-capable client can use it.
- **Composable:** Claude can chain tools from several servers in one task.

## How it works

```
You → Claude → MCP client → MCP server → external service
```

**What a server offers (3 primitives)**

| Primitive | What it is | Example |
|---|---|---|
| **Tools** | Functions Claude can call (name, description, JSON-schema params) | `send_email`, `create_issue` |
| **Resources** | Readable data with a URI, like a GET endpoint | `file:///config`, a ticket list |
| **Prompts** | Ready-made templates the server provides | `summarize_pr` |

Claude reads each tool's **description** to decide when to call it.

**Transports**

| Type | Runs | Use for |
|---|---|---|
| `stdio` | Local process on your machine | Files, local scripts |
| `http` | Remote URL | Cloud services (Gmail, GitHub…) |

**Scopes**

| Scope | Stored in | Who gets it |
|---|---|---|
| local (default) | `~/.claude.json`, per project | Only you, this project |
| project | `.mcp.json` in the repo | Everyone who clones |
| user | `~/.claude.json` | Only you, all projects |

If names clash, project scope wins inside that project.

**Discover → register → authenticate**
1. *Discovery:* at start, Claude asks each server for its tool list.
2. *Registration:* tell Claude where the server is (URL or command).
3. *Auth:* OAuth 2.0, API key / bearer token, or none.

**Handy commands:** `/mcp` (list servers, status, tools) · `claude mcp list` · `claude mcp get <name>`

**Claude.ai connectors:** Gmail, Drive, Notion and others are available as built-in connectors under Settings → Connectors. They use OAuth.

## Try it on the CSV project
Connect a ready-made server and use it. For example, the Filesystem server so Claude can browse the data folder:
```bash
claude mcp add --transport stdio --scope user filesystem -- npx -y @modelcontextprotocol/server-filesystem ./sample-project/data
```
```
> /mcp                                   # confirm "filesystem: connected"
> List the files in the data folder and tell me how many rows sales.csv has.
```
Watch the tool call appear, then disconnect the server (`claude mcp remove filesystem`) and ask again. Note how Claude falls back.

## Security (read this)
- **Prompt injection:** text in a tool result can try to give Claude orders. Treat tool output as data.
- **Tool poisoning:** a malicious server can write misleading tool descriptions. Install only servers you trust.
- **Credential exposure:** keep tokens out of committed files (see module 05).

## Gotchas
- Many connected servers means a crowded tool list. Connect only what you need.
- A server that's down simply vanishes from Claude's tools. Check `/mcp` first.
