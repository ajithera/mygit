# 01 · Introduction & Getting Started

## What it is
Claude Code is an AI coding agent that runs in your terminal (or IDE). It reads your project, edits files, runs commands and answers questions about your code. You talk to it in plain language.

## Why use it
- It understands the whole project, not just the file you paste.
- It does the typing: it edits files, runs tests and fixes failures.
- `CLAUDE.md` gives it standing project knowledge, so you don't repeat yourself every session.

## How it works

**Two ways of working**

| | Interactive | Agentic |
|---|---|---|
| You | Go back and forth | Give one goal, step away |
| Best for | Unclear tasks, learning a codebase | Well-defined, repetitive, multi-file work |
| Control | High, every step | Lower, review at the end |

**Core commands**

| Type | What it does |
|---|---|
| `claude` | Start a session in the current folder |
| `claude "task"` | Start with a task |
| `claude --continue` | Resume the last session |
| `@file.py` | Pull a file into the prompt |
| `!pytest` | Run a shell command; output goes into context |
| `/clear` | Wipe conversation (keeps memory files) |
| `/compact` | Summarize the conversation to free context |
| `/help` `/status` `/memory` `/init` | Help, session info, edit memory, generate CLAUDE.md |
| `Esc` | Stop what Claude is doing |
| `Shift+Tab` / `/plan` | Plan mode: Claude proposes, you approve |

**Context window** = everything Claude can hold in mind at once: files read, conversation, `CLAUDE.md`, command output. Unread files cost nothing. When it fills up, use `/compact` or `/clear`.

**Memory files**

| File | Scope | In Git? |
|---|---|---|
| `CLAUDE.md` (project root) | Whole team | Yes |
| `CLAUDE.local.md` | Just you, this project | No |
| `~/.claude/CLAUDE.md` | You, all projects | No |
| Auto memory (`/memory`) | Notes Claude writes itself | No |

Keep `CLAUDE.md` under about 200 lines: facts, not long procedures.

## Try it on the CSV project
```bash
cd sample-project
claude
> /init                                   # Claude writes a first CLAUDE.md
> What does csv_reader.py do? Which function handles filtering?
> @csv_reader.py @tests/test_csv_reader.py are the tests complete?
> !python3 -m unittest discover tests
```
Then edit `CLAUDE.md` to hold what Claude must always know:
```markdown
# CSV Reader
- Run: python3 csv_reader.py data/sales.csv [--category X]
- Test: python3 -m unittest discover tests
- Python stdlib only. No new dependencies.
- price is float, qty is int. Never change function signatures without asking.
```

## Gotchas
- Claude can be confidently wrong. Read the diff and run the tests before committing.
- Never paste secrets (`.env`, keys). Describe the format instead.
- Use plan mode and a Git branch for risky or large changes.
- Start with narrow permissions and widen them only when needed.
