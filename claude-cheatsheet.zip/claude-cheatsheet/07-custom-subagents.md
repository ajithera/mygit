# 07 · Building Custom Subagents

## What it is
Designing subagents that do one narrow job well: a tight system prompt, only the tools they need, a sensible scope, and tests to prove they behave.

## Why use it
- A narrow agent gives predictable, repeatable output.
- Least-privilege tools limit the damage a mistake can do.
- Tested agents can be trusted in pipelines.

## How it works

**1. Write a narrow system prompt.** Cover these parts (a tight 200 words beats a loose 1000):

| Part | Example |
|---|---|
| Role (one sentence) | "You are a CSV code reviewer." |
| Input | "You receive one Python file path." |
| Task (strong verbs) | "Check error handling, edge cases, typing." |
| Output (exact format) | "Return a bullet list: `[CRITICAL|WARNING|INFO] file:line – issue`." |
| Constraints | "Never edit files. Never run code." |
| Escalation | "If the file isn't Python, reply `not_python` and stop." |
| Scope | "You review. You don't fix, commit or explain basics." |

**2. Assign tools by role**

| Agent type | Tools |
|---|---|
| Reviewer / researcher | `Read`, `Grep`, `Glob` (read-only) |
| Test runner | `Bash`, `Read`, with `disallowedTools: Write, Edit` |
| Formatter / summariser | `model: haiku`, minimal tools |
| MCP-using agent | Give it only the MCP servers it needs, read-only tokens |

**3. Pick scope:** project (`.claude/agents/`) for team conventions, user (`~/.claude/agents/`) for personal helpers.

**4. Pass context deliberately.** A subagent doesn't see your chat. Put what it needs in the request: file paths, goal, constraints. Don't paste everything, since selective context is cleaner and cheaper. Optional: `memory: user` lets an agent keep notes across sessions in `~/.claude/agent-memory/<name>/`.

**5. Test it.** Build a small prompt matrix:

| Case | Example |
|---|---|
| Golden path | A normal Python file → proper findings |
| Partial input | Empty file |
| Wrong input | A `.csv` file instead of code → agent escalates |
| Ambiguous | Conflicting instructions → consistent behaviour |
| Tool limit | Ask a read-only agent to "fix it" → it declines |

**6. Manage agents:** `/agents` opens a menu with a Library tab (built-in, project, user), a Running tab, "Create new agent" (including "Generate with Claude"), and edit (`e`) / delete (`d`).

## Try it on the CSV project
`.claude/agents/csv-reviewer.md`
```markdown
---
name: csv-reviewer
description: Use this agent to review csv_reader.py or its tests for bugs and missing edge cases. Read-only.
model: sonnet
tools:
  - Read
  - Grep
  - Glob
---
You are a Python code reviewer for a small CSV script.
Review only the files you are given. Check: bad CSV values, empty files, division/None cases, missing tests.
Output a bullet list: [CRITICAL|WARNING|INFO] file:line – issue – suggested fix (as text).
Never edit files. If no issues, output "No findings."
```
`.claude/agents/test-runner.md` (`tools: Bash, Read`, `model: haiku`): runs `python3 -m unittest discover tests` and summarises failures.

Try: *"Use csv-reviewer on csv_reader.py"* then *"Use test-runner, then csv-reviewer on any file with failures."*

## Gotchas
- "Be helpful" prompts produce unpredictable agents. Use verbs, formats and prohibitions.
- Description is how Claude picks an agent, so make it a clear trigger.
- Subagents can't call other subagents. Orchestrate from the main session (or use agent teams).
