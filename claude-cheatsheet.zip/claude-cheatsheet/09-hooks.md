# 09 · Hooks (Pre / Post Triggers)

## What it is
A hook is a script that Claude Code runs automatically at a fixed moment, such as before a tool runs, after a file edit, or when a session starts. You configure hooks in `settings.json`. They are the deterministic, always-runs part of your workflow, unlike a prompt, which Claude may or may not follow.

## Why use it
- **Guardrails:** block dangerous commands or protected files.
- **Automation:** format, test or log after every edit.
- **Context:** inject live project info at session start.
- **Audit:** keep a record of what Claude changed.

## How it works

**Events**

| Event | Fires | Typical use | Matcher? |
|---|---|---|---|
| `SessionStart` | Session starts or resumes | Inject branch, test status | `startup`, `compact` |
| `UserPromptSubmit` | Before Claude sees your prompt | Validate, block | No |
| `PreToolUse` | Before a tool call | Allow / deny / ask | Tool name, e.g. `Edit\|Write`, `Bash` |
| `PostToolUse` | After a tool call | Format, test, log | Tool name |
| `Stop` | Claude finishes a turn | Reminders | No |
| `Notification` | Claude needs you | Desktop alert | e.g. `idle_prompt` |
| `PostToolUseFailure`, `StopFailure` | After a failure | Rollback, error logs | Tool name |

**Config** (`.claude/settings.json` for the project, `~/.claude/settings.json` for you)
```json
{
  "hooks": {
    "PreToolUse": [
      { "matcher": "Edit|Write|MultiEdit",
        "hooks": [ { "type": "command", "command": "python3",
                     "args": ["${CLAUDE_PROJECT_DIR}/.claude/hooks/protect_data.py"] } ] }
    ],
    "PostToolUse": [
      { "matcher": "Edit|Write|MultiEdit",
        "hooks": [ { "type": "command", "command": "python3",
                     "args": ["${CLAUDE_PROJECT_DIR}/.claude/hooks/run_tests.py"],
                     "statusMessage": "Running tests..." } ] }
    ]
  }
}
```
Hooks can be written in any language. They read a **JSON event on stdin** (`tool_name`, `tool_input.file_path`, `tool_input.command`, `prompt`, `session_id`…).

**How a hook answers**

| To do this | Output |
|---|---|
| Allow silently | `exit 0`, no output |
| Block with a message (any event) | Message on **stderr**, `exit 2` |
| Structured decision (PreToolUse) | JSON `{"hookSpecificOutput": {"hookEventName":"PreToolUse","permissionDecision":"deny"\|"ask"\|"allow","permissionDecisionReason":"..."}}` and `exit 0` |
| Feed info back to Claude (Post / Stop) | JSON `{"additionalContext": "..."}`, `exit 0` |
| Inject context (SessionStart) | Plain text on stdout |

Use `exit 2` or JSON, not both. Add `"async": true` for background work (logging) that must not slow Claude.

**Scope and chaining**

| Scope | File | Notes |
|---|---|---|
| Project | `.claude/settings.json` | Committed, whole team |
| User | `~/.claude/settings.json` | Personal, never committed |

- All hooks matching an event run **in parallel**.
- For PreToolUse, **deny beats ask beats allow**.
- Multiple `additionalContext` strings are concatenated.
- A failing PostToolUse hook can't undo the action. Use PreToolUse to prevent, and PostToolUseFailure or Git to recover.

Check what's registered with `/hooks`.

## Try it on the CSV project
Save these as `.claude/hooks/protect_data.py` and `.claude/hooks/run_tests.py`, then register them with the JSON above.

```python
# protect_data.py — PreToolUse: stop edits to the sample data
import json, os, sys

event = json.load(sys.stdin)
path = event.get("tool_input", {}).get("file_path", "")
if os.path.basename(path) == "sales.csv":
    print(json.dumps({"hookSpecificOutput": {
        "hookEventName": "PreToolUse",
        "permissionDecision": "deny",
        "permissionDecisionReason": "data/sales.csv is protected. Edit it by hand.",
    }}))
sys.exit(0)
```
```python
# run_tests.py — PostToolUse: run the tests after any .py edit
import json, subprocess, sys

event = json.load(sys.stdin)
path = event.get("tool_input", {}).get("file_path", "")
if path.endswith(".py"):
    result = subprocess.run(["python3", "-m", "unittest", "discover", "tests"],
                            capture_output=True, text=True)
    status = "passed" if result.returncode == 0 else "FAILED:\n" + result.stderr[-500:]
    print(json.dumps({"additionalContext": f"Tests after editing {path}: {status}"}))
sys.exit(0)
```
Test a hook without Claude: `echo '{"tool_input":{"file_path":"data/sales.csv"}}' | python3 .claude/hooks/protect_data.py`

Then ask Claude: *"Add a comment to data/sales.csv"* (blocked) and *"Add a docstring to csv_reader.py"* (tests run automatically).

## Gotchas
- Hook paths: use `${CLAUDE_PROJECT_DIR}` for project hooks, `${HOME}` for user hooks.
- Stderr + `exit 2` blocks. JSON + `exit 2` is ignored. Pick one.
- Keep hooks fast. A slow hook slows every turn.
- Never let a logging hook crash the workflow. Catch its errors.
